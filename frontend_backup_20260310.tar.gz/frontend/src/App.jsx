import LuxuryDashboard from './components/LuxuryDashboard.jsx'

export default function App() {
  return <LuxuryDashboard />
}
